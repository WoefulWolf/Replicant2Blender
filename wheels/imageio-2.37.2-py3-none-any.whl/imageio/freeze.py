"""
Helper functions for freezing imageio.
"""


def get_includes():
    return ["email", "urllib.request", "numpy", "zipfile", "io"]


def get_excludes():
    return []
